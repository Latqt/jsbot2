const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  	if (!bot.config.admins.includes(message.author.id)) {
  		return message.reply('Sorry, you dont have the perms!!!')
  	}

    if(!args || args.length < 1) return message.reply("Must provide a command name to reload.");
    const commandName = args[0];
    // Check if the command exists and is valid
    if(!bot.commands.has(commandName)) {
      return message.reply("That command does not exist");
    }
    // the path is relative to the *current folder*, so just ./filename.js
    try{
      delete require.cache[require.resolve(`./${commandName}.js`)];
      // We also need to delete and reload the command from the bot.commands Enmap
      bot.commands.delete(commandName);
      const props = require(`./${commandName}.js`);
      bot.commands.set(commandName, props);
      message.channel.send(`The command \`${commandName}\` has been reloaded`);
    }catch(err) {}
    try{
      delete require.cache[require.resolve(`../main-commands/${commandName}.js`)];
    // We also need to delete and reload the command from the bot.commands Enmap
    bot.commands.delete(commandName);
    const props = require(`../main-commands/${commandName}.js`);
    bot.commands.set(commandName, props);
    message.channel.send(`The command \`${commandName}\` has been reloaded`);
    }catch(error){}

    try{
      delete require.cache[require.resolve(`../economy-commands/${commandName}.js`)];
    // We also need to delete and reload the command from the bot.commands Enmap
    bot.commands.delete(commandName);
    const props = require(`../economy-commands/${commandName}.js`);
    bot.commands.set(commandName, props);
    message.channel.send(`The command \`${commandName}\` has been reloaded`);
    }catch(error){}
}

module.exports.config = {
    name: "reload",
    description: "reload a command",
    usage: "reload [command]",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
