const { MessageEmbed } = require("discord.js")
const { inspect } = require("util");
const Discord =require("discord.js")
const { getMember } = require("../functions.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  if(message.author.id !== '700159668114292786'){ return }

		if (args.length < 1) return message.channel.send("You must specify a user and a command to execute as the user")
		const user = await getMember(message, args[0]);
		if (user.user.id === message.author.id) { return message.channel.send("I can't find that user.") }
			user.tag = `${user.user.tag}`
			if (!args[1]) return message.channel.send("Please mention a valid command");
			let x = true
			if (x) {
				user.com = true;
			}
			let noexec = await db.get("noexecute" + user.user.id)
			if (noexec) {
				return message.channel.send("You cannot execute commands on this user")
			}
		const furtherArgs = args.slice(2);
			user.color = `#000000`
		const command = bot.commands.get(args[1].toLowerCase()) || bot.commands.find(cmd => cmd.config.aliases && cmd.config.aliases.includes(args[1].toLowerCase()));
		if (!command) return message.channel.send(`Please mention a valid command`);
		const Message = Object.assign({}, message, {
			author: user,
			channel: message.channel,
			guild: message.guild,
			member: user,
		});
		console.log(Message)

  let c = db.get('color' + user.id);
  if(!color){ color = bot.config.defaultHexColor };

	command.run(bot, Message, furtherArgs, db, prefix, c)
		.catch((x) => {
	message.channel.send("There seems to have been an error when executing this command as " + user.tag + ":\n" + inspect(x, { depth: 0 }), { code: 'js' })
	})
}
module.exports.config = {
    name: "execute",
    description: "Evaluates command",
    usage: "+execute [user] [command]",
    accessableby: "Members",
    aliases: ["evaluate"],
    guildOnly: true,
}
