const Discord =require("discord.js")
const { getMemberNoSelf } = require("../functions.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {

  if(!message.member.hasPermission('KICK_MEMBERS')){
      return message.channel.send(":x: | You don't have permission");
  }

    if(args < 1){return message.channel.send('Supply an id or mention a user')}
    const user = getMemberNoSelf(message, args.join(" "));

      let bannerHighRole = message.member.roles.highest.position;
      let getBannedHighRole = user.roles.highest.position;
      if (bannerHighRole < getBannedHighRole) return message.channel.send("You cannot kick users that have higher roles than you!");

      if (bannerHighRole === getBannedHighRole) return message.channel.send("You cannot kick users that have same highest role!");

  		if (user === message.author) return message.channel.send('You can\'t kick yourself');

      if (user) {
        const member = message.guild.member(user);

  			let reason = args.slice(1).join(' ');
  			if(!reason) reason = "No reason provided";

        const readyEmbed = new Discord.MessageEmbed()
      .setTitle("**KICK COMMAND USED**")
      .addField("Executor:", message.author.id)
      .addField("Kicked user:", user.user.id)
      .addField("Reason:", reason)

          if (member) {
            member.kick({ reason: `${reason}` }).then(() => {
              message.channel.send(`Successfully kicked ${user}.`)
              let channel = bot.channels.cache.get(`${bot.channels.modLog}`)
              if(!channel) {
                return
              };
              channel.send(readyEmbed);
            }).catch(err => {
              message.channel.send("I was unable to kick the member");
              console.error(err);
            });
          } else {
            message.channel.send("That user isn't in this server!");
          }
      } else {
        message.channel.send("You didn't mention the user to kick!");
  	}
}
module.exports.config = {
    name: "kick",
    description: "Kick a member",
    usage: "*kick [member]",
    accessableby: "Members",
    aliases: [],
    guildOnly: true,
}
