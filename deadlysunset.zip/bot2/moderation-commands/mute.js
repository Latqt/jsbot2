const Discord = require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  if(message.guild){
    if (!message.member.hasPermission('MUTE_MEMBERS')) return message.channel.send(`**${message.author.username}, Sorry, you need MUTE_MEMBERS Permission to use this commands!`).then(msg => msg.delete(7000));
    if (!message.guild.member(bot.user).hasPermission("MANAGE_ROLES")) return message.channel.send(`${message.author.username}, Sorry, I need the following permission to \`mute\` command to work: \`MANAGE_ROLES\``).then(msg => msg.delete(7000));

    let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!member) return message.channel.send(`${message.author.username}, Sorry, I can't find the user you mean!`);

    let muterole = message.guild.roles.cache.find(x => x.name === 'Muted');
    if (!muterole) {
      try {
        muterole = await message.guild.roles.cache.create({
          name: 'Muted',
          color: '#000000',
          permission: []
        });
        message.guild.channels.cache.forEach(async (channel, id) => {
          await channel.overwritePermissions(muterole, {
            SEND_MESSAGES: false,
            ADD_REACTION: false,
            CONNECT: false
          });
        });
      } catch (e) {
        console.log(e.message);
      }
    };

    if (member.roles.cache.has(muterole.id)) return message.channel.send(`${member.user.username} Has already muted.`)
    await (member.roles.add(muterole));
    message.channel.send(`${member.user.username}, *Has been muted*.`);
  }
}
module.exports.config = {
  name: "mute",
  description: "Mute a user",
  usage: "mute <user>",
  accessableby: "Mods",
  aliases: [],
  guildOnly: true,
}
