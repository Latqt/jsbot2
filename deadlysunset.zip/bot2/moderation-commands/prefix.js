const Discord = require("discord.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  if(!message.member.hasPermission('MANAGE_GUILD')){
      return message.channel.send(":x: | You don't have permission to kick members");
  }

  let newPrefix = args[0];
  if(!newPrefix){
    return message.channel.send(`${message.author} You must mention a new prefix`)
  }
  if(newPrefix.length > 5){
    return message.channel.send(`${message.author} The prefix length must be shorter than 5.`)
  }

  if(newPrefix){
    const confirm = `${prefix}confirmprefix`;
    message.reply(`Are you sure you want to set your server prefix to ${newPrefix}?\nThis will mean instead of starting with ${prefix}, commands will start with ${newPrefix}, like this: ${newPrefix}help\n\nIf you are sure you want to do this, type \`${confirm}\`.`);

    const filter = m => m.author.id == message.author.id;
    let cancel = false;
    let AwaitFetch = await message.channel.awaitMessages(filter, { max: 1, time: 30_000, errors: ['time'] }).catch((x) => {});
    let Await = AwaitFetch.first().content || "x";

    if (Await != confirm) {
    	cancel = true;
    	return message.channel.send("Request has been cancelled");
    }

    if (cancel != true) {
      db.set("prefix" + message.guild.id, `${newPrefix}`)
  	  message.channel.send(`Set server prefix to ${newPrefix}.`)
    }
  }
}
module.exports.config = {
    name: "prefix",
    description: "Set the prefix",
    usage: "prefix <new prefix>",
    accessableby: "Manage Guild",
    aliases: [],
    guildOnly: true,
}
