const Discord =require("discord.js")
const enmap = require("enmap")
const fs = require('fs');
const ms = require('ms');

module.exports.run = async (bot, message, fejbfjwifbeijbwfes, db, prefix, color) => {
  const client = bot;
  if (message.author.id !== '700159668114292786') {
  return message.channel.send('Sorry, you dont have the perms!!!')
  }

  const clean = text => {
    text = text.toString();
    if (text.includes(bot.token)) {
      text = text.replace(bot.token, 'Not for your evil eyes!');
    }
    if (typeof text === 'string') {
      return text.replace(/`/g, `\`${String.fromCharCode(8203)}`).replace(/@/g, `@${String.fromCharCode(8203)}`);
    }
    return text;
	}

  const args = message.content.split(" ").slice(1);

		function escapeRegExp(str) {
			return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, '\\$1');
		}

		function evaluate(input) {
			let result = eval(input);
			if (result)
				result = result.toString().replace(new RegExp(escapeRegExp(token), 'g'), '<token removed>');
			return result;
		}

	  try {
      const code = args.join(" ");
      let evaled = eval(code);

      if (typeof evaled !== "string")
        evaled = require("util").inspect(evaled);

      message.channel.send(clean(evaled), {code:"xl"});
    } catch (err) {
      message.channel.send(`\`ERROR\` \`\`\`xl\n${clean(err)}\n\`\`\``);
    }
};

module.exports.config = {
    name: "eval",
    description: "Evaluates command",
    usage: "+eval",
    accessableby: "Members",
    aliases: ["evaluate"],
    guildOnly: false,
		cooldown: 3,
    permissionRequired: 9, // 0 All, 1 Kick Perm, 2 Ban perm, 3 Manage Guild, 4 Mod, 5 Administrator, 6 Bot Moderator, 7 Bot Admin, 8 Bot Owner, 9 Jeff
}
