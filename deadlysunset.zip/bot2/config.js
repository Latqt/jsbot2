const config = {
	functions: {
		Inspect: function (element, penetrate) {
			return require("util").inspect(element, { depth: isNaN(penetrate) ? 1000000000000000000000000 : Number(penetrate) });
		},
    capitalizeFirstLetter: function(string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
    },
	},
	// Bot config
	config: {
		inv: "https://discord.com/api/oauth2/authorize?client_id=794410441103245322&permissions=8&scope=bot",
		token: "Nzk0NDEwNDQxMTAzMjQ1MzIy.X-6aYA.1zxhCajiyHETlEWDlAa0ldMPeiE",
		adminds: [ "641358627235430415", "700159668114292786", "709934790769377281" ],
		prefix: 'd!', // Bot prefix change if required
		defaultHexColor: "#000000", // Default hex color for embeds
		mainServerID: "794114862330150922", //ID
		owner: '641358627235430415', // Owner ID
		version: '1.0.0', // Bot version
		channels: { // Some channels for logging
			ready: "795159963248099369",
			error: "795160023771774976",
			modLog: "795160066348548116",
		},
		roles: {// Add the roles if you need, not really required for most things

		},
		emoji: { // Only used if their not default discord emojis
			bal: '💵'
		}
	},
};

module.exports = config;
