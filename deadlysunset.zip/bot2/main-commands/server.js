const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  if(!message.guild){
    return
  }
  let embed = new Discord.MessageEmbed()
  .setTitle(`Server stats for: \`${message.guild.name}\``)
  .addField(`Member size:`, `${message.guild.members.cache.size}`, true)
  .addField(`Total channels:`, `${message.guild.channels.cache.size}`, true)
  .addField(`Total roles:`, `${message.guild.roles.cache.size}`, true)
  .setTimestamp()
  message.channel.send(embed)
}
module.exports.config = {
    name: "server",
    description: "Server statistics",
    usage: "server",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
