const Discord =require("discord.js")
const { Permissions } = require('discord.js');
const { getMember } = require("../functions.js");
const { stripIndents } = require("common-tags");
const util = require('util');
const moment = require('moment');

module.exports.run = async (bot, message, args, db, prefix, color) => {
    const member = getMember(message, args.join(" "));

    let year = moment.utc(member.joinedAt).format('YYYY')
    let month = moment.utc(member.joinedAt).format('MMM')
    let day = moment.utc(member.joinedAt).format('DD')
    let time = moment.utc(member.joinedAt).format('HH:MM')
    let joined = `${month} ${day}, ${year} at ${time}`;

    let roles = member.roles.cache
        .filter(r => r.id !== message.guild.id)
        .map(r => r).join(" ") || 'None';
    if(roles.length > 1000){
      roles = 'Too many roles'
    }

    let year1 = moment.utc(member.user.createdAt).format('YYYY')
    let month1 = moment.utc(member.user.createdAt).format('MMM')
    let day1 = moment.utc(member.user.createdAt).format('DD')
    let time1 = moment.utc(member.user.createdAt).format('HH:MM')
    let registered = `${month1} ${day1}, ${year1} at ${time1}`;

  function getPermName(bitfield = 0) {
    for (let key in Discord.Permissions.FLAGS)
    if (Discord.Permissions.FLAGS[key] == bitfield) return key;
    return null;
  }

  let permLevel = `Member`
  if(member.hasPermission("MANAGE_EMOJIS")){
    permLevel = `Server Emoji Manager`
  }
  if(member.hasPermission("KICK_MEMBERS")){
    permLevel = `Server Moderator`
  }
  if(member.hasPermission("BAN_MEMBERS")){
    permLevel = `Server Moderator`
  }
  if(member.hasPermission("MANAGE_GUILD")){
    permLevel = `Server Manager`
  }
  if(member.hasPermission("ADMINISTRATOR")){
    permLevel = `Administrator`
  }

  function format(str) {
    let newStr = str.replace(/_+/g, " ").toLowerCase();
    newStr = newStr.split(/ +/).map(x => `${x[0].toUpperCase()}${x.slice(1)}`).join(' ');
    return newStr.replace('Vad', 'VAD').replace('Tts', "TTS");
  }
  let map;
  if (member) {
     map = Object.keys(Permissions.FLAGS).map(x => {
       if (member.hasPermission(x)) {
         return format(x);
       } else {
         return 'false';
       };
     }).join(", ").replace(/false, /g,'').replace(", false",'');
  };
  const bits = member.permissions.bitfield;

    const embed = new Discord.MessageEmbed()
        .setAuthor(`${member.user.tag}`, member.user.displayAvatarURL())
        .setThumbnail(member.user.displayAvatarURL())
        .setColor(member.displayHexColor === '#000000' ? '#ffffff' : member.displayHexColor)
        .setDescription(`<@${member.user.id}>`)
        .addField(`** Joined**`, `${joined}`, true)
        .addField(`** Registered**`, `${registered}`, true)
        .addField(`** Roles:** [${member.roles.cache.size}]`, `${roles}`)
        .addField(`Permissions:`, `${map}`)
        .addField(`Permission Level:`, `${permLevel}`)
        .addField('User information:', stripIndents`** ID:** ${member.user.id}
        ** Username:** ${member.user.username}
        ** Tag:** ${member.user.tag}`, true)
        .setFooter(member.displayName, member.user.displayAvatarURL)
        .setTimestamp()
        .setColor(color)
    if (member.user.presence.game)
        embed.addField('Currently playing', stripIndents`** Name:** ${member.user.presence.game.name}`);

    message.channel.send(embed);
}

module.exports.config = {
    name: "profile",
    description: "Pulls the userinfo of yourself or a user!",
    usage: "profile (@mention)",
    accessableby: "Members",
    aliases: [ "userinfo", "whois" ],
    guildOnly: true,
}
