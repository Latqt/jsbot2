const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  let channel = args[0];
  let msg = args.splice(1).join(` `);
  if(!channel || !msg){
    return message.channel.send(`Format is: ${prefix}anony <channel id> <message>`)
  }
  if(channel && msg){
    let c = bot.channels.cache.get(channel);
    if(!c){
      return message.channel.send(`Unable to find targetted channel.`)
    }
    const bannedWords = [ "nigger", "nigga", "cunt", "bitch", "porn", "sex", "nudes", "fuck" ]
    for (var i = 0; i < bannedWords.length; i++) {
    if (msg.includes(bannedWords[i])) {
      // message.content contains a forbidden word;
      // delete message, log, etc.
      return message.channel.send('Your message has been filtered and some word(s)')
      break;
    }
  }
    c.send(msg)
  }
}
module.exports.config = {
    name: "anony",
    description: "PONG! Displays the api & bot latency",
    usage: "anony <channel id> <message>",
    accessableby: "Members",
    aliases: [ "latency" ],
    guildOnly: false,
}
