const Discord = require("discord.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  message.delete()

  const c = args[0];
  let text = args.slice(1).join(' ');
  if(!text || !c) {return message.channel.send(`The format is ${prefix}e <color hex> <message>`)};

  let embed = new Discord.MessageEmbed()
  .setColor(`${c}`)
  .setDescription(text)

  message.channel.send(embed)
  const modlog = bot.channels.cache.get(`${bot.config.channels.modLog}`)
  const modEmbed = new Discord.MessageEmbed()
  .setColor(`#000000`)
  .setTitle('**Embed Created**')
  .setDescription(`**Embed was created by:** ${message.author.tag}\n **Executor ID** ${message.author.id} \n **Message in embed was:** ${text} \n **Color was:** ${color}`)

  modlog.send(modEmbed)
}
module.exports.config = {
    name: "embed",
    description: "Sends messages in an embed",
    usage: "embed",
    accessableby: "Members",
    aliases: [ "e" ],
    guildOnly: false,
}
