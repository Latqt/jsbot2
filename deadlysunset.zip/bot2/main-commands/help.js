const Discord = require("discord.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  const helpEmbed = new Discord.MessageEmbed()
    .setColor(color)
    .setTitle('Help')
    .setAuthor('Nooby Fat O', 'http://clipart-library.com/images/pioA768MT.jpg')
    .setDescription(`peepee poopoo bot - looking for "${prefix}`)
    .addFields(
        { name: `${prefix}help`, value: 'Always return here for help.', inline: true },
        { name: `${prefix}ping`, value: 'To find ping in ms.', inline: true },
        { name: `${prefix}anony [message]`, value: 'Send anonymous msg', inline: true },
        { name: `${prefix}snipe`, value: 'Check last deleted message.', inline: true },
        { name: `${prefix}server`, value: 'Shows server information.', inline: true },
        { name: `${prefix}cmention`, value: 'Custom mention responses', inline: true },
        { name: `${prefix}custom`, value: `Custom tags you can create with custom bot replies. `, inline: true },
        { name: `${prefix}profile`, value: 'See user profile.', inline: true },
        { name: `${prefix}avatar <user>`, value: 'See user profile picture.', inline: true },
        { name: `${prefix}stats`, value: 'Shows bot statistics', inline: true },
        { name: `${prefix}uptime`, value: 'Shows bot uptime', inline: true },
    )
    .setTimestamp()
    .setFooter('Whoa, not woah. Get it right.');
  message.channel.send(helpEmbed);
}
module.exports.config = {
    name: "help",
    description: "Shows help command",
    usage: "help",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
