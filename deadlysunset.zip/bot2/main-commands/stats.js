const { MessageEmbed } = require("discord.js");
const nosu = require("node-os-utils");
const Discord = require("discord.js");
const ms = require("ms");

module.exports.run = async (bot, message, args, db, prefix, color) => {
		let mem = process.memoryUsage().heapUsed / 1024 / 1024;
		let cpu = await nosu.cpu.usage();
		var getUptime = function(millis) {
    var dur = {};
    var units = [{
            label: "ms",
            mod: 1000
        },
        {
            label: "s",
            mod: 60,
        },
        {
            label: "m",
            mod: 60,
        },
        {
            label: "hrs",
            mod: 24
        },
        {
            label: "d",
            mod: 31
        }
    ];

    units.forEach(function(u) {
        millis = (millis - (dur[u.label] = (millis % u.mod))) / u.mod;
    });

    var nonZero = function(u) {
        return dur[u.label];
    };
    dur.toString = function() {
        return units
						.reverse()
            .filter(nonZero)
            .map(function(u) {
                return dur[u.label] + "" + (dur[u.label] == 1 ? u.label.slice(0, -1) : u.label);
            })
            .join('');
    };
    return (dur);
};
const msg = await message.channel.send("", {
		embed: new MessageEmbed()
		.setColor(color)
		.setTitle('Bot Information')
		.setAuthor(bot.user.tag, bot.user.avatarURL())
		.addField('• Name:', bot.user.tag, true)
		.addField('• CPU Usage:', `\`${cpu}%\``, true)
		.addField("• Servers Cached:", bot.guilds.cache.size, true)
		.addField("• Channels Cached:", bot.channels.cache.size, true)
		.addField('• Users Cached:', bot.users.cache.size, true)
		.addField('• Created On:', bot.user.createdAt.toDateString(), true)
		.addField('• Memory Usage:', `${Math.trunc(mem)}/${Math.trunc(process.memoryUsage().rss / 1024 / 1024)} MB`, true)
		.addField('• Total Commands:', bot.commands.size, true)
		.setTimestamp()
	});
}
module.exports.config = {
    name: "stats",
    description: "Bot statistics",
    usage: "stats",
    accessableby: "Members",
    aliases: [],
		guildOnly: false,
}
