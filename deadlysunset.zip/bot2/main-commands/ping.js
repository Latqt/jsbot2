const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  message.channel.send("Pinging...").then(m => {
      let ping = m.createdTimestamp - message.createdTimestamp
      let choices = ["Your ping is:", "Your ping:", "Heres your ping:", "Ping:"]
      let response = choices[Math.floor(Math.random() * choices.length)]

      m.edit(`${response} Bot Latency: \`${ping}\`, API Latency: \`${Math.round(bot.ws.ping)}\``)
  })
}
module.exports.config = {
    name: "ping",
    description: "PONG! Displays the api & bot latency",
    usage: "ping",
    accessableby: "Members",
    aliases: [ "latency" ],
    guildOnly: false,
}
