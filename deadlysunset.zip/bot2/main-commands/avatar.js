const Discord = require("discord.js");
const colours = require("../colours.json");
const { getMember, formatDate} = require("../functions.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  const member = getMember(message, args.join(" "));
  let embed = new Discord.MessageEmbed()
  .setColor(color)
  .setTitle(`${member.user.username}'s avatar`)
  .setImage(member.user.displayAvatarURL({ format: "png", dynamic: true, size: 256}))
  message.channel.send(embed)
};

module.exports.config = {
    name: "avatar",
    description: "Posts a mentioned person's pfp",
    usage: "avatar [user]",
    accessableby: "Members",
    aliases: [ "av" ],
    guildOnly: false,
}
