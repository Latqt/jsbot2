const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  let type = args[0];
  if(!type){
    return message.channel.send(`Format is either: ${prefix}custom add <word> <response> or ${prefix}custom delete <word> or ${prefix}custom edit <name> <new response> or ${prefix}custom <word>`)
  }
  if(type === 'add' || type === 'create'){
    let kw = args[1];
    let response = args.splice(2).join(` `);
    if(!kw || !response){
      return message.channel.send(`Format is ${prefix}custom add <name> <response>`)
    }
    if(kw && response){
      let check3 = db.get(`custom${kw}`);
      if(check3){
        return message.channel.send(`Sorry, that custom tag is made already`)
      }
      await db.set(`custom${kw}`, `${response};${message.author.id}`);
      return message.channel.send(`Added custom: ${kw} with the response ${response}`)
    }
  }
  if(type === 'delete' || type === 'del'){
    let kw = args[1];
    if(!kw){
      return message.channel.send(`Format is ${prefix}custom delete <name>`)
    }
    let check4 = await db.get(`custom${kw}`);
    if(check4){
      let c = check.split(`;`)
      if(message.author.id === c[1]){
        db.delete(`custom${kw}`)
        return message.channel.send(`Delete custom command tag with \`${kw}\``)
      }
      if(message.author.id !== c[1]){
        return message.channel.send(`You may only delete commands that you made`)
      }
    }
    if(!check4){
      return message.channel.send(`Thats not a made command`)
    }
  }
  if(type === 'edit'){
    let kw = args[1];
    let r2 = args.splice(2).join(` `);
    if(!kw || !r2){
      return message.channel.send(`Format is ${prefix}custom edit <name> <new response>`)
    }
    if(kw && r2){
      let check4 = await db.get(`custom${kw}`);
      if(check4){
        let c = check.split(`;`)
        if(message.author.id === c[1]){
          db.delete(`custom${kw}`)
          return message.channel.send(`Delete custom command tag with \`${kw}\``)
        }
        if(message.author.id !== c[1]){
          return message.channel.send(`You may only delete commands that you made`)
        }
      }
    }
  }
  let check2 = db.get(`custom${type}`);
  if(check2){
    let r = check2.split(`;`)
    message.channel.send(r[0])
  }
  if(!check2){
    message.channel.send('Custom tag not found')
  }
}
module.exports.config = {
    name: "custom",
    description: "PONG! Displays the api & bot latency",
    usage: "custom <word> <reponse>",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
