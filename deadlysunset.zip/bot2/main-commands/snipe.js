const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  if(!message.guild){
    return
  }

  let sniped = await db.get("snipeMsg" + message.channel.id);
  let snipeAuthor = await db.get("snipeID" + message.channel.id);

  if(!sniped || !snipeAuthor){
    return message.channel.send(`No sniped message`);
  }

  if(sniped && snipeAuthor){
    message.channel.send("", {
      embed: new Discord.MessageEmbed()
      .setTitle(`Sniped Message`)
      .setDescription(`Sniped Message: \`${sniped}\` \n Message by: \`${bot.users.cache.get(snipeAuthor).tag}\``)
    })
  }
}
module.exports.config = {
    name: "snipe",
    description: "Snipes a deleted message",
    usage: "snipe",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
