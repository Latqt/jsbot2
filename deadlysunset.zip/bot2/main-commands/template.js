const Discord =require("discord.js")

module.exports.run = async (bot, message, args, db, prefix, color) => {

}
module.exports.config = {
    name: "template",
    description: "template",
    usage: "template",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
