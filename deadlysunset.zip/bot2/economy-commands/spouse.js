const Discord =require("discord.js")
const { getUser } = require("../functions.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  const x = args.join(" ");
  let user = getUser(message, bot, x);
  if(!user){ user = message.author }
  const spouse = await db.get("spouse" + user.id);
  if(spouse){
    let embed = new Discord.MessageEmbed()
    .setDescription(`${user.tag} is married to ${bot.users.cache.get(spouse).tag}`)
    .setColor(color)

    message.channel.send(embed)
  }
  if(!spouse){
    return message.channel.send(`They're not married to anybody`)
  }

}
module.exports.config = {
    name: "spouse",
    description: "Show your spouse",
    usage: "+spouse",
    accessableby: "Members",
    aliases: [],
    guildOnly: false,
}
