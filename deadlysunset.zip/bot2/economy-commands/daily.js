const Discord =require("discord.js")
const ms = require("ms")

module.exports.run = async (bot, message, args, db, prefix, color) => {
  let user = message.author;
  const cooldowndata = await db.get("dailyc" + user.id) || 0;
  if(parseInt(cooldowndata) > Date.now()){ return message.reply(`Please wait ${ms(parseInt(cooldowndata) - Date.now(), {long: true})} before claiming another daily reward.`) }

  const currentBalance = await db.get("bal" + user.id) || 0;

  await db.set("bal" + user.id, `${parseInt(currentBalance) + parseInt(10)}`);

  await message.channel.send(new Discord.MessageEmbed()
  .setTitle(":money_with_wings: Daily Reward!")
  .setDescription(`You have claimed your daily reward of 💵 10, you current balance is 💵 ${parseInt(currentBalance) + parseInt(10)}!`)
  .setColor(color))

  await db.set("dailyc" + user.id, Date.now() + ms("1d"))
}
module.exports.config = {
    name: "daily",
    description: "Get your daily coins",
    usage: "+daily",
    accessableby: "Members",
    aliases: [],
    guildOnly: true,
}
