const Discord =require("discord.js")
const { getUser } = require("../functions.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  const x = args.join(" ");
  let user = getUser(message, bot, x);
  if(!user){ user = message.author }
  await db.ensure("bal" + user.id, 0);
  const bal = await db.get("bal" + user.id);

  let embed = new Discord.MessageEmbed()
  .setDescription(`${user.tag} balance contains :dollar: ${bal}`)
  .setColor(color)

  message.channel.send(embed)
}
module.exports.config = {
    name: "balance",
    description: "Show your balance",
    usage: "+balance",
    accessableby: "Members",
    aliases: [ "bal" ],
    guildOnly: false,
}
