const Discord =require("discord.js")
const { getUser } = require("../functions.js");

module.exports.run = async (bot, message, args, db, prefix, color) => {
  const spouse = await db.get("spouse" + message.author.id);
  if(!spouse){
    return message.channel.send('You\'re not married to anyone right now')
  }
  if(spouse){
    db.delete("spouse" + message.author.id)
    message.channel.send("", {
      embed: new Discord.MessageEmbed()
      .setDescription(`${message.author.tag} has officially divorced ${bot.users.cache.get(spouse).tag || 'lol'}`)
      .setColor(color)
    })
  }
}
module.exports.config = {
    name: "divorce",
    description: "Divorce",
    usage: "+divorce",
    accessableby: "Members",
    aliases: [ ],
    guildOnly: false,
}
