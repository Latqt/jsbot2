const Discord =require("discord.js")
const { getUser, trimWithoutDot, isHex } = require("../functions.js")

module.exports.run = async (bot, message, args, db, prefix, ccc) => {
  await db.ensure(`${message.author.id}-color`, `#09ffff`)
  let color = args[0];
  if(!color){ return message.channel.send(`You must specify a hexadecimal color code for this command`) }
  if(color.length < 6){ return message.channel.send(`You must specify a hexadecimal color code for this command to work!`) }

  let c = color
  if(c.includes('#')){
    let x = trimWithoutDot(color, 7)
    c = x
  }
  if(!c.includes('#')){
    let x = trimWithoutDot(color, 6)
    c = `${'#' + x}`
  }

  let hcheck = isHex(c)
  if(hcheck === false){
    return message.channel.send(`You must specify a hexadecimal color code for this command to work!`)
  }

  let embed = new Discord.MessageEmbed()
  .setDescription(`${message.author.tag} has successfully updated their color preference to ${c}`)
  .setColor(`${c}`)

  if(!color.includes('#')){
    let x = trimWithoutDot(color, 9)
    db.set('color' + message.author.id, `${'#' + x}`)
    message.channel.send(embed)
  }
  if(color.includes('#')){
    let x = trimWithoutDot(color, 10)
    db.set('color' + message.author.id, `${x}`)
    message.channel.send(embed)
  }
};
module.exports.config = {
    name: "color",
    description: "Changes color on the command bar, you can change the colors by using the colors hex code.",
    usage: "+color <hex>",
    accessableby: "Users",
    aliases: [],
    guildOnly: false
}
