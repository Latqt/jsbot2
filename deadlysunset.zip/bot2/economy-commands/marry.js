const Discord =require("discord.js")
const { getUser } = require("../functions.js");
const timeOfTimeout = 60000;
const watched = new Discord.Collection();

module.exports.run = async (bot, message, args, db, prefix, color) => {

  const c = message;
  const x = args.join(" ");
  let user = getUser(message, bot, x);
  if(!user){ return message.channel.send(`You must mention the user you wish to marry for this to work! Format is: ${prefix}marry @user123`) }
  const married = await db.get("spouse" + message.author.id);
  const married2 = await db.get("spouse" + user.id);
  if(married2){
    return message.channel.send(`${user.tag} is already married to ${bot.users.cache.get(married2).tag}`)
  }
  if(married){
    return message.channel.send(`Don't try and cheat on ${bot.users.cache.get(married).tag}! You can use ${prefix}divorce if you don't like them`)
  }
  if(!married){
    const filter = m => m.author.id === user.id;
    const msg = message;
    const channel = msg.channel;

    if(watched.has(message.author.id)) {
      return message.channel.send('Your already proposing to a user')
    }

    message.channel.send('They have 60 seconds to reply yes')

    const collector = channel.createMessageCollector(filter, () => true);

    collector.on('collect', async message => {
      if (message.content.toLowerCase() === `yes`) {
        await db.set("spouse" + c.author.id, user.id);
        await db.set("spouse" + user.id, c.author.id);
        message.channel.send(`${user.tag} and ${c.author.tag} have successfully become a newly wed couple!`)
        watched.get(c.author.id).stop();
        watched.delete(c.author.id);
      }
    })
    watched.set(c.author.id, collector);
    collector.on('end', m => {
      watched.delete(c.author.id)
    })
    // Auto timeout
    setTimeout(() => {
      if(watched.has(c.author.id)) {
        watched.get(c.author.id).stop();
        watched.delete(c.author.id);
      }
    }, timeOfTimeout);
  }
}
module.exports.config = {
    name: "marry",
    description: "Marry a user",
    usage: "+marry",
    accessableby: "Members",
    aliases: [ ],
    guildOnly: false,
}
