const enmap = require('enmap');

module.exports = {
    getMember: function(message, toFind = '') {
        toFind = toFind.toLowerCase();

        let target = message.guild.members.cache.get(toFind);

        if (!target && message.mentions.members)
            target = message.mentions.members.first();

        if (!target && toFind) {
            target = message.guild.members.cache.find(member => {
                return member.displayName.toLowerCase().includes(toFind) ||
                member.user.tag.toLowerCase().includes(toFind)
            });
        }

        if (!target)
            target = message.member;

        return target;
    },

    isHex: function(str){
      return /^#(?:[0-9a-fA-F]{3}){1,2}$/.test(str);
    },
    trimWithoutDot: function(str, max) {
      var returnable = ((str.length > max) ? `${str.slice(0, max)}` : str);
      return returnable;
    },
    
    getDefaultChannel: function(guild){
      var Long = require("long");
      // get "original" default channel
      if(guild.channels.cache.has(guild.id))
      return guild.channels.cache.get(guild.id)

      // Check for a "general" channel, which is often default chat
      const generalChannel = guild.channels.cache.find(channel => channel.name === "general");
      if (generalChannel)
      return generalChannel;
      // Now we get into the heavy stuff: first channel in order where the bot can speak
      // hold on to your hats!
      return guild.channels.cache
      .filter(c => c.type === "text" &&
      c.permissionsFor(guild.client.user).has("SEND_MESSAGES"))
      .sort((a, b) => a.position - b.position || Long.fromString(a.id).sub(Long.fromString(b.id)).toNumber())
      .first();
    },

    trim: function(str, max) {
      var returnable = ((str.length > max) ? `${str.slice(0, max - 3)}...` : str);
      return returnable;
    },

    commaNumber: function numberWithCommas(x) {
        return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
    },

    getMemberShoot: function(message, toFind = '') {
        toFind = toFind.toLowerCase();

        let target = message.guild.members.cache.get(toFind);

        if (!target && message.mentions.members)
            target = message.mentions.members.first();

        if (!target && toFind) {
            target = message.guild.members.cache.find(member => {
                return member.displayName.toLowerCase().includes(toFind) ||
                member.user.tag.toLowerCase().includes(toFind)
            });
        }

        return target;
    },

    getMemberNoSelf: function(message, toFind = '') {
        toFind = toFind.toLowerCase();

        let target = message.guild.members.cache.get(toFind);

        if (!target && message.mentions.members)
            target = message.mentions.members.first();

        return target;
    },
    getUser: function(message, bot, toFind = '') {
        toFind = toFind.toLowerCase();

        let target = bot.users.cache.get(toFind);

        if (!target && message.mentions.users)
            target = message.mentions.users.first();
        return target;
    },
    formatDate: function(date) {
        return new Intl.DateTimeFormat('en-US').format(date)
    },
    getPermissionLevel: function(member, bot){
      // 0 All, 1 Kick Perm, 2 Ban perm, 3 Manage Guild, 4 Mod, 5 Administrator, 6 Bot Moderator, 7 Bot Admin, 8 Bot Owner, 9 Jeff
      if(bot.config.owners[0] === member.user.id) return 9;
      if(bot.config.owners.includes(member.user.id)) return 8;
      if(bot.config.admins.includes(member.user.id)) return 7;
      if(bot.config.moderators.includes(member.user.id)) return 6;
      if(member.hasPermission('MANAGE_GUILD')) return 5;
      if(member.hasPermission('MANAGE_GUILD')) {
        if(member.hasPermission('KICK_MEMBERS')){
          if(member.hasPermission('BAN_MEMBERS')) {
            if(member.hasPermission('MANAGE_EMOJIS')){
              return 4;
            }
          }
        }
      }
      if(member.hasPermission('MANAGE_GUILD')) return 3;
      if(member.hasPermission('BAN_MEMBERS')) return 2;
      if(member.hasPermission('KICK_MEMBERS')) return 1;
      if(check === `true`) return 1;
      return 0;
    },
    promptMessage: async function (message, author, time, validReactions) {
        time *= 1000;

        for (const reaction of validReactions) await message.react(reaction);


        const filter = (reaction, user) => validReactions.includes(reaction.emoji.name) && user.id === author.id;

        return message
            .awaitReactions(filter, { max: 1, time: time})
            .then(collected => collected.first() && collected.first().emoji.name);
    }
};
