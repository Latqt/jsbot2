'use strict'

// Create the bot client
const Discord = require("discord.js");
const bot = new Discord.Client();

// Config and local stored json files
const configFile = require('./config.js');
// General Requirements
const fs = require("fs");
const enmap = require('enmap');
const db = new enmap({
  name: "db",
  cloneLevel: "deep",
  fetchAll: true,
  autoFetch: true
});

// Collections
const cooldowns = new Discord.Collection();
bot.commands = new Discord.Collection();
bot.mainCommands = new Discord.Collection();
bot.moderationCommands = new Discord.Collection();
bot.economyCommands = new Discord.Collection();
bot.aliases = new Discord.Collection();
bot.config = new Object(configFile.config);
bot.log = console.log()
bot.db = db;
bot.keys = [ "bal" ]

require("./utill/eventHandler.js")(bot, db)
require("./utill/commandParser.js")(bot)

bot.on('debug', (e) => { console.log(e) })

process.on('unhandledRejection', (e) => {
  console.error(e);

	let errorEmbed = new Discord.MessageEmbed()
	.setColor('#da0000')
	.setDescription(`:x: **Error:** => \`${e}\`\n`)
	.setTimestamp()

  let log = bot.channels.cache.get(`${bot.config.channels.error}`)
  if(!log){ return }
  log.send(errorEmbed)
});

bot.on("message", async message => {
  // Prefix
  if(message.guild){ var prefix = await db.get('prefix' + message.guild.id) };
  if(!prefix){ prefix = bot.config.prefix };
  // Color
  let color = await db.get('color' + message.author.id);
  if(!color){ color = bot.config.defaultHexColor };

  if (!message.content.startsWith(prefix)) return;

  let args = message.content.slice(prefix.length).split(/ +/g);
  let cmd = args.shift().toLowerCase();
  let commandfile = bot.commands.get(cmd) || bot.commands.get(bot.aliases.get(cmd));

  if(commandfile) { return commandfile.run(bot, message, args, db, prefix, color)};
})

bot.on("messageDelete", async message => {
  if(message.author.bot){
    return
  }
  if(message.attachments.size > 0) {
    return
   }
  if(message.embed){
   return
  }
  if(message.guild){
    await db.set("snipeMsg" + message.channel.id, `${message}`)
    await db.set("snipeID" + message.channel.id, `${message.author.id}`)
  }
})

bot.login(bot.config.token);
